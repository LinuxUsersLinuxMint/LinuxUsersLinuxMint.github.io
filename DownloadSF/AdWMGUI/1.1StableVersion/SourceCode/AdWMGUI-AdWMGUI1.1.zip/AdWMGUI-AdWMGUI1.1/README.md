AdWMGUI (Advanced Windows Manager GUI)

Türkçe:

* AdWMGUI yazılımı 03/01/2024 (1 Mart, 2024) tarihinde github dan indirilmek üzere yayımlanmıştır.
* AdWMGUI'yi LinuxUsersLinuxMint web sitesinden indirmek için: https://linuxuserslinuxmint.github.io/Contents/adwmgui/STEP_2/TR/index.html

English:

* AdWMGUI software will be released for download from github on 03/01/2024 (March 1, 2024).
* AdWMGUI software was released for download from github on 03/01/2024 (March 1, 2024). 

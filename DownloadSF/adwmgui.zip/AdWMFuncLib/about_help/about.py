#!/usr/bin/python3

from tkinter import *
from _tkinter import TclError
from tkinter import messagebox
from tkinter import filedialog
from tkinter import simpledialog
from tkinter import Tk

def AboutMsgBox():
    messagebox.showinfo("About", "AdWMGUI (Advanced Windows Manager GUI) version: 1.0, version_type: GUI Beta (For GUI), licence: GPL2")
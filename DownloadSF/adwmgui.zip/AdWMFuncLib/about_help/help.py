#!/usr/bin/python3

from tkinter import *
from _tkinter import TclError
from tkinter import messagebox
from tkinter import filedialog
from tkinter import simpledialog
from tkinter import Tk

def HelpMsgBox():
    messagebox.showinfo("Help", "Help Web Site: https://linuxuserslinuxmint.github.io/")